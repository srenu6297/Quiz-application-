package quiz;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import quiz.Questions;
import quiz.Login;
import java.awt.Color;
import java.awt.Font;
/**
 * @author SriL3kh@ and G0v@rdhan
 *
 */

public class Results extends JFrame 
{
	private JPanel contentPane;
	private JButton Again;
	private JButton Exit;
	private JButton Answers;
	public static String results;
	private boolean login;
	protected java.lang.String Spassword;
	

	static final String DB_URL = "jdbc:mysql://localhost/sys";
	
	static final String USER = "root";
	static final String PASS = "root";
	protected static final String String = null;
	
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try  
				{
					Results frame = new Results();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}


	public Results()
	{	
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 752, 701);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		int results=Questions.score;
		String result=String.valueOf(results);
		
	
		JLabel username = new JLabel("<html>Hey....<html>"+Login.usernameq+"!");
		username.setFont(new Font("Tahoma", Font.BOLD, 20));
		username.setBounds(231, 93, 192, 135);
		contentPane.add(username);
		results=10-results;
		String wrong=String.valueOf(results);
		
		JLabel finalresult = new JLabel("<html>Your FinalScore is:<html>"+result+"<html><br><br>Total Right Answers: <html>"+result+"<html><br><br>Total Wrong Answers: <html>"+wrong);
		finalresult.setFont(new Font("Tahoma", Font.BOLD, 20));
		finalresult.setBounds(220, 202, 283, 189);
		contentPane.add(finalresult);
		
		
		Exit = new JButton("Exit");
		Exit.setFont(new Font("Tahoma", Font.BOLD, 20));
		Exit.setBounds(566, 534, 108, 47);
		contentPane.add(Exit);
		Exit.addActionListener(new ActionListener() 
                {
		                public void actionPerformed(ActionEvent e) 
                                {				
                                
		                	System.exit(0);
                                }
		});
	
	
		Again = new JButton("Play Again");
		Again.setFont(new Font("Tahoma", Font.BOLD, 20));
		Again.setBounds(52, 534, 149, 47);
		contentPane.add(Again);	
		Again.addActionListener(new ActionListener() 
		{

		    public void actionPerformed(ActionEvent e) {
		        
		        new Login().setVisible(true); 
		        dispose();
		    }

		});
		
		
		Answers = new JButton("Answers");
		Answers.setFont(new Font("Tahoma", Font.BOLD, 20));
		Answers.setBounds(314, 534, 131, 47);
		contentPane.add(Answers);	
		Answers.addActionListener(new ActionListener() 
		{

		    public void actionPerformed(ActionEvent e) {
		        
		        new Answers().setVisible(true); 
		        dispose();
		    }

		});
			
		
		
}}