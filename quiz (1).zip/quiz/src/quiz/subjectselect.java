package quiz;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class subjectselect extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					subjectselect frame = new subjectselect();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public subjectselect() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 877, 591);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("choose subject");
		lblNewLabel.setForeground(new Color(0, 0, 128));
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 46));
		lblNewLabel.setBounds(171, 32, 414, 68);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("1.   DBMS Quiz");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new Questions().setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(72, 149, 313, 39);
		contentPane.add(btnNewButton);
		
		JButton btnCQuiz = new JButton("2.    C++  Quiz");
		btnCQuiz.setHorizontalAlignment(SwingConstants.LEFT);
		btnCQuiz.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnCQuiz.setBounds(72, 229, 313, 39);
		contentPane.add(btnCQuiz);
		
		JButton btnDbmsQuiz = new JButton("3.   Operating System Quiz");
		btnDbmsQuiz.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDbmsQuiz.setBounds(72, 304, 313, 39);
		contentPane.add(btnDbmsQuiz);
		
		JButton btnComputerNetwork = new JButton("4.  Computer network Quiz");
		btnComputerNetwork.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnComputerNetwork.setBounds(72, 377, 313, 39);
		contentPane.add(btnComputerNetwork);
		
		JButton btnDataStructure = new JButton("5.    Data Structure Quiz");
		btnDataStructure.setHorizontalAlignment(SwingConstants.LEFT);
		btnDataStructure.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDataStructure.setBounds(72, 455, 313, 39);
		contentPane.add(btnDataStructure);
	}
}
