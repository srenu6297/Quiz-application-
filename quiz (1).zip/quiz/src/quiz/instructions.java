package quiz;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class instructions extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					instructions frame = new instructions();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public instructions() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 877, 591);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblInstructions = new JLabel("instructions");
		lblInstructions.setForeground(new Color(0, 0, 128));
		lblInstructions.setFont(new Font("Algerian", Font.BOLD, 46));
		lblInstructions.setBounds(204, 34, 414, 68);
		contentPane.add(lblInstructions);
		
		JTextArea txtrTheClock = new JTextArea();
		txtrTheClock.setWrapStyleWord(true);
		txtrTheClock.setFont(new Font("Monospaced", Font.BOLD, 20));
		txtrTheClock.setEditable(false);
		txtrTheClock.setLineWrap(true);
		txtrTheClock.setText("1. The clock will set at the server. The countdown timer at the top corner of screen will display the remaining time available for you to complete the quiz when the timer reaches zero the quiz  will end by itself.\n\n2. Procedure for answering a multiple choice questions (MCQ) : 1. CHOOSE ONE ANSWER FROM THE FOUR OPTION GIVEN BELOW THE QUESTIONS.\n\n3. TO SAVE YOUR ANSWER CLICK ON NEXT BUTTON.\n\n4. Please do not use calculator or smart watches.");
		txtrTheClock.setBounds(25, 138, 828, 318);
		contentPane.add(txtrTheClock);
		
		JSeparator separator = new JSeparator();
		separator.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		separator.setAutoscrolls(true);
		separator.setBackground(Color.DARK_GRAY);
		separator.setBounds(852, 100, -841, 2);
		contentPane.add(separator);
		
		JButton btnStartQuiz = new JButton("Start Quiz");
		btnStartQuiz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new subjectselect().setVisible(true);
				dispose();
			}
		});
		btnStartQuiz.setHorizontalAlignment(SwingConstants.LEFT);
		btnStartQuiz.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnStartQuiz.setBounds(248, 485, 145, 39);
		contentPane.add(btnStartQuiz);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Login().setVisible(true);
				dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnBack.setBounds(454, 485, 119, 43);
		contentPane.add(btnBack);
	}
}
