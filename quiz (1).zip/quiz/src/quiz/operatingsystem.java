package quiz;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.GroupLayout;
import java.awt.Font;
import java.awt.Color;
/**


 */

public class operatingsystem extends JFrame 
{
	
	private JPanel contentPane; 
	private JButton Next;
	private JButton Back;
	private ButtonGroup opg;
	private JRadioButton op1;
	private JRadioButton op2;
	private JRadioButton op3;
	private JRadioButton op4;
	private JLabel question;
	private JLabel username;
	private JSeparator separator;
	 String[][] a;
	 String[][] q;
	static int score=0;
	int count=0;
	int c=0;
	static String usernameq;
	
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run()
			{
				try 
				{
					operatingsystem frame = new operatingsystem();
					frame.setVisible(true);
				} 
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			
		});
		
	}
	
	public operatingsystem() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        score=0;
        
        Game();
      q =new String[10][5];
      //Questions are stored in q[][]
      q[0][0]="1. Which of the following is not an operating system?";
      q[0][1]=" Windows";
      q[0][2]=" Linux";
      q[0][3]=" DOS";
      q[0][4]=" Oracle";
      
      q[1][0]="2. When was the first operating system developed?";
      q[1][1]=" 1948";
      q[1][2]=" 1949";
      q[1][3]=" 1950";
      q[1][4]="1951";
      
      q[2][0]="3. What is the mean of the Booting in the operating system?";
      q[2][1]="Restarting computer";
      q[2][2]="Install the program";
      q[2][3]="To scan";
      q[2][4]="To turn off";
      
      q[3][0]="4. What is an operating system?";
      q[3][1]=" collection of programs that manages hardware resources";
      q[3][2]="system service provider to the application programs";
      q[3][3]="interface between the hardware and application programs";
      q[3][4]="All of the mentioned";
      
      q[4][0]="5. Which of the following Is not a part of the operating system?";
      q[4][1]="Input/output control program";
      q[4][2]="Job control program";
      q[4][3]=" Supervisor ";
      q[4][4]="Performance monitor";
      
      q[5][0]="6. Where is operating system placed in the memory?";
      q[5][1]="in the low memory";
      q[5][2]="in the high memory";
      q[5][3]="either low or high memory";
      q[5][4]="none of the mentioned";
      
      q[6][0]="7. Operating system is a collection of_____";
      q[6][1]="Software routines";
      q[6][2]="Input-output devices";
      q[6][3]="Hardware components";
      q[6][4]="All of the above";
      
      q[7][0]="8. which of the following is/are CPU scheduling algorithms?";
      q[7][1]="Round Robin";
      q[7][2]="Shortest Job First";
      q[7][3]="Priority";
      q[7][4]="All of these";
      
      q[8][0]="9. What is the name of the operating system that reads and reacts in terms of actual time?";
      q[8][1]="Real time system";
      q[8][2]="Time sharing system";
      q[8][3]="Quick response system";
      q[8][4]="Batch system";
      
      q[9][0]="10.Which one of the following errors will be handle by the operating system?";
      q[9][1]="power failure";
      q[9][2]="lack of paper in printer";
      q[9][3]="connection failure in the network";
      q[9][4]="all of the mentioned";
      //Answers are stored in a[][]
      a=new String[10][5];
      a[0][1]="Oracle";
      a[1][1]="1950";
      a[2][1]="Restarting computer";
      a[3][1]="All of the mentioned";
      a[4][1]="Performance monitor";
      a[5][1]="either low or high memory";
      a[6][1]="Software routines";
      a[7][1]="All of these";
      a[8][1]="Real time system";
      a[9][1]="all of the mentioned";
     


      start(0);
	}
	 
	 public String[][] qarray() {
	        return q.clone();
	    }
	 public String[][] ansarray() {
	        return a.clone();
	    }
	private void Game()
	{	
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		opg=new ButtonGroup();
		op1=new JRadioButton();
		op1.setFont(new Font("Tahoma", Font.BOLD, 15));
		op2=new JRadioButton();
		op2.setFont(new Font("Tahoma", Font.BOLD, 15));
		op3=new JRadioButton();
		op3.setFont(new Font("Tahoma", Font.BOLD, 15));
		op4=new JRadioButton();
		op4.setFont(new Font("Tahoma", Font.BOLD, 15));
		question=new JLabel();
	   //  question).setLineWrap(true);
		question.setFont(new Font("Tahoma", Font.BOLD, 18));
		username=new JLabel();
		username.setFont(new Font("Tahoma", Font.BOLD, 18));
		separator=new JSeparator();
		Next=new JButton();
		Next.setFont(new Font("Tahoma", Font.BOLD, 18));
		Back=new JButton();
		Back.setFont(new Font("Tahoma", Font.BOLD, 18));
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);


        final JLabel timer = new JLabel("05:00");
        timer.setLocation(388, 22);
        timer.setForeground(new Color(0, 0, 139));
        timer.setFont(new Font("Tahoma", Font.BOLD, 22));
        final Timer t = new Timer(1000, new ActionListener() {
            int time = 300;
            @Override
            public void actionPerformed(ActionEvent e) {
                time--;
                timer.setText(format(time / 60) + ":" + format(time % 60));
                if(c>=10) {
                    final Timer timer = (Timer) e.getSource();
                	timer.stop();
                }else {
                if (time == 0) {
                	if(c>=10) {
                    final Timer timer = (Timer) e.getSource();
                    timer.stop();
                	}else {
                    JOptionPane.showMessageDialog(null,"Time Up Click Ok To Check Your Score","bye..",JOptionPane.ERROR_MESSAGE);
                    System.out.println(score);
        			new Results().setVisible(true);
        			dispose();
                	}
                }
            }
            }
            
        });
        t.start();
       
        opg.add(op1);
        op1.setText("option1");
        op1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                op1Selected(evt);
            }

		
        });

        opg.add(op2);
        op2.setText("option2");
        op2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                op2selected(evt);
            }

		
        });

        opg.add(op3);
        op3.setText("option3");
        op3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                op3selected(evt);
            }

        });

        opg.add(op4);
        op4.setText("option4");
        op4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                op4selected(evt);
            }

			
        });

        question.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        question.setText("question");
        username.setText("Playing As:"+Login.usernameq);
        Next.setText("Next");
        Next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextClicked(evt);
            }

        });
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackClicked(evt);
            }

        });
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
        	gl_contentPane.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGap(10)
        			.addComponent(username)
        			.addGap(748)
        			.addComponent(Next, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE))
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGap(21)
        			.addComponent(timer, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
        			.addGap(6)
        			.addComponent(question, GroupLayout.PREFERRED_SIZE, 737, GroupLayout.PREFERRED_SIZE)
        			.addGap(70)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        				.addComponent(Back)
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addGap(35)
        					.addComponent(separator, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGap(56)
        			.addComponent(op1)
        			.addGap(791)
        			.addComponent(op2))
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGap(56)
        			.addComponent(op3)
        			.addGap(791)
        			.addComponent(op4))
        );
        gl_contentPane.setVerticalGroup(
        	gl_contentPane.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGap(13)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addGap(2)
        					.addComponent(username, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
        				.addComponent(Next, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE))
        			.addGap(12)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addGap(17)
        					.addComponent(timer, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addGap(1)
        					.addComponent(question, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addComponent(Back, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
        					.addGap(6)
        					.addComponent(separator, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)))
        			.addGap(2)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        				.addComponent(op1)
        				.addComponent(op2))
        			.addGap(45)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        				.addComponent(op3)
        				.addComponent(op4)))
        );
        contentPane.setLayout(gl_contentPane);

	pack();
	}    

	

	protected void BackClicked(ActionEvent evt) {
	
		if(c==0) {
			
		}else {
			if(score==c)
			{
		score--;
		c--;
		start(c);
			}
			else {
				c--;
				start(c);
			}
		}
		
	}
	protected void NextClicked(ActionEvent evt) {
		
		
		if(getSelectedButtonText(opg)==a[c][1]) {
			score++;
			count++;
			c++;
		}
		else
		{
			c++;
			count++;
		}
			if(c!=10)
		{
			start(c);
		System.out.println(score);
		}
		else {
			System.out.println(score);
			new Results().setVisible(true);
			this.dispose();
		}
	}
	protected void op4selected(ActionEvent evt) {
	
		
	}
	protected void op3selected(ActionEvent evt) {
	
		
	}
	protected void op2selected(ActionEvent evt) {
		
		
	}
	protected void op1Selected(ActionEvent evt) {
	
		
	}
	String getSelectedButtonText(ButtonGroup buttonGroup) {
		    for (Enumeration buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {
		        AbstractButton button = (AbstractButton) buttons.nextElement();

		        if (button.isSelected()) {
		            return button.getText();
		        }
		    }
		    return null;
	}
	public void start(int i) {
		
		 question.setText(q[i][0]);
	        op1.setText(q[i][1]);
	        op2.setText(q[i][2]);
	        op3.setText(q[i][3]);
	        op4.setText(q[i][4]);
	        opg.clearSelection();


		
	}
	private static String format(int i) {
        String result = String.valueOf(i);
        if (result.length() == 1) {
            result = "0" + result;
        }
        return result;
    }
	

		 }

